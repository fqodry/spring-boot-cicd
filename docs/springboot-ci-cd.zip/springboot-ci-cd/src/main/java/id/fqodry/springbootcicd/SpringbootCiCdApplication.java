package id.fqodry.springbootcicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCiCdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCiCdApplication.class, args);
	}

}
